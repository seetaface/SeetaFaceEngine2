package com.seeta.sdk;

public class SeetaPointF
{
	public double x;
	public double y;
}
