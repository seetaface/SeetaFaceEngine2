package com.seeta.sdk;

public class SeetaRect
{
	public int x;
	public int y;
	public int width;
	public int height;
}
